/**
 * Schema 示例生成与字段树递归 — 占位实现
 *
 * 完整递归逻辑在 TASK-030 实现。
 * 当前版本只处理基本类型和一层 object/array，不递归展开 $ref。
 * 目的：让 requestBuilder 和 OperationDebugModel 在 TASK-032 就能生成初始值。
 */
import type { BuildSchemaExampleFn, BuildSchemaFieldTreeFn } from './types';
/**
 * 简易 schema → 示例值生成（不递归展开 $ref，仅处理基本类型和一层嵌套）
 *
 * TASK-030 会替换为完整实现（递归 $ref、allOf/oneOf/anyOf、循环引用检测、maxDepth）
 */
export declare const buildSchemaExample: BuildSchemaExampleFn;
/**
 * 简易字段树生成（占位） — TASK-030 实现
 */
export declare const buildSchemaFieldTree: BuildSchemaFieldTreeFn;
