/**
 * OperationDebugModel — 从 OAS2/OAS3 operation 解析出统一的调试参数模型
 *
 * 职责：
 * - 将 OAS2 的 parameters[].in = body/formData 和 OAS3 的 requestBody 统一为 OperationDebugModel
 * - OAS2 的 `in=body` → bodyContents
 * - OAS2 的 `in=formData` → 根据 consumes 判断 urlencoded / multipart
 * - OAS3 的 requestBody.content → bodyContents（多种 media type）
 * - 解析 $ref 引用的参数（path-level parameters 也合并进来）
 */
import type { OperationDebugModel, SchemaResolveContext } from './types';
/** OAS3 ParameterObject（简化） */
interface OAS3Param {
    name?: string;
    in?: string;
    required?: boolean;
    description?: string;
    schema?: Record<string, unknown>;
    example?: unknown;
    deprecated?: boolean;
    $ref?: string;
}
/** OAS2 ParameterObject（简化） */
interface OAS2Param {
    name?: string;
    in?: 'query' | 'header' | 'path' | 'formData' | 'body';
    required?: boolean;
    description?: string;
    type?: string;
    format?: string;
    schema?: Record<string, unknown>;
    example?: unknown;
    default?: unknown;
    enum?: unknown[];
    deprecated?: boolean;
    $ref?: string;
    items?: Record<string, unknown>;
    allowMultiple?: boolean;
}
/** OAS3 RequestBodyObject（简化） */
interface OAS3RequestBody {
    description?: string;
    required?: boolean;
    content?: Record<string, {
        schema?: Record<string, unknown>;
        example?: unknown;
        examples?: Record<string, unknown>;
        encoding?: Record<string, unknown>;
    }>;
    $ref?: string;
}
/** 通用 Operation（兼容 OAS2/OAS3） */
interface OperationLike {
    parameters?: Array<OAS3Param | OAS2Param>;
    requestBody?: OAS3RequestBody;
    consumes?: string[];
}
/** 通用 PathItem（包含 path-level parameters） */
interface PathItemLike {
    parameters?: Array<OAS3Param | OAS2Param>;
    get?: OperationLike;
    put?: OperationLike;
    post?: OperationLike;
    delete?: OperationLike;
    patch?: OperationLike;
    head?: OperationLike;
    options?: OperationLike;
    [key: string]: unknown;
}
/** 文档结构（最小公共接口） */
interface DocLike {
    openapi?: string;
    swagger?: string;
    paths?: Record<string, PathItemLike>;
    components?: {
        parameters?: Record<string, OAS3Param>;
        requestBodies?: Record<string, OAS3RequestBody>;
        schemas?: Record<string, unknown>;
        [key: string]: unknown;
    };
    definitions?: Record<string, unknown>;
    parameters?: Record<string, OAS2Param>;
    consumes?: string[];
    [key: string]: unknown;
}
export interface BuildDebugModelOptions {
    /** 完整 OpenAPI 文档 */
    doc: DocLike;
    /** URL path（如 /api/users/{id}） */
    path: string;
    /** HTTP 方法（小写） */
    method: string;
    /** 是否 OAS2 */
    isOAS2?: boolean;
    /** schema 解析上下文（maxDepth 等） */
    schemaCtx?: SchemaResolveContext;
}
/**
 * 从 OpenAPI operation 解析出统一的调试参数模型
 */
export declare function buildOperationDebugModel(options: BuildDebugModelOptions): OperationDebugModel;
export {};
