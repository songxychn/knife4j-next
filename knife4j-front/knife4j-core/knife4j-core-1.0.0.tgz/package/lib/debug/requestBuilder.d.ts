/**
 * requestBuilder — 纯函数，构造请求对象 + curl 命令
 *
 * 输入：operation 信息 + 用户填写值 + 全局参数 + 鉴权
 * 输出：{ url, method, headers, query, body, contentType } + curl 字符串
 *
 * 不依赖浏览器 API，不依赖框架。
 */
import type { OperationDebugModel, DebugFormValues, GlobalParamValues, AuthValues, BuiltRequest, ValidationError } from './types';
/** 替换 path 参数：{id} → 实际值 */
export declare function replacePathParams(path: string, pathParams: Record<string, string>): string;
/** 拼接 query 字符串 */
export declare function buildQueryString(queryParams: Record<string, string>): string;
/** 多来源 headers 合并，后者覆盖前者 */
export declare function mergeHeaders(...sources: Array<Record<string, string> | undefined>): Record<string, string>;
/** 将鉴权信息转化为 headers */
export declare function authToHeaders(auth: AuthValues | undefined): Record<string, string>;
/** 全局参数按位置拆分 */
export declare function splitGlobalParams(globalParams: GlobalParamValues | undefined): {
    headers: Record<string, string>;
    queries: Record<string, string>;
};
/** 校验必填参数，返回缺失列表 */
export declare function validateRequired(model: OperationDebugModel, form: DebugFormValues): ValidationError[];
export interface BuildRequestOptions {
    /** 基础 URL（如 http://localhost:8080） */
    baseUrl: string;
    /** URL path（如 /api/users/{id}） */
    path: string;
    /** HTTP 方法 */
    method: string;
    /** 解析后的调试模型 */
    debugModel: OperationDebugModel;
    /** 用户填写的表单值 */
    formValues: DebugFormValues;
    /** 全局参数 */
    globalParams?: GlobalParamValues;
    /** 鉴权信息 */
    auth?: AuthValues;
}
/**
 * 构建最终请求对象
 */
export declare function buildRequest(options: BuildRequestOptions): BuiltRequest;
/**
 * 从 BuiltRequest 生成等价 curl 命令
 */
export declare function buildCurl(req: BuiltRequest): string;
