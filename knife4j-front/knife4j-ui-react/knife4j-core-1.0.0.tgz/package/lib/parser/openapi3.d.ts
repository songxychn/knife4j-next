/**
 * OpenAPI3解析器
 */
export declare class Name {
    add(): void;
}
