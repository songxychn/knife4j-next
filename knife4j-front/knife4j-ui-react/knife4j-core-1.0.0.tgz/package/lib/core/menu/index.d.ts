declare class Menu {
    name: string;
    constructor(name: string);
    sayHi(): string;
    sayYes(userName: string): string;
}
export default Menu;
