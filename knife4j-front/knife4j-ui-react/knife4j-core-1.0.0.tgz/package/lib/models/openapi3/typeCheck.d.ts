import { ParameterObject, ReferenceObject } from "./types";
import { SchemaObject } from "./types";
declare const OpenAPI3TypeUtils: {
    /**
     * 判断是否ParameterObject类型
     * @param obj 对象
     * @returns
     */
    isParameterObject(obj: any): obj is ParameterObject;
    /**
     * 判断是否ReferenceObject类型
     * @param obj 对象
     * @returns
     */
    isReferenceObject(obj: any): obj is ReferenceObject;
    isSchemaObject(obj: any): obj is SchemaObject;
};
export default OpenAPI3TypeUtils;
