import { BaseCommonParser } from '../knife4j/BaseCommonParser';
import { Knife4jParseOptions } from '../knife4j/Knife4jParseOptions';
import { Knife4jInstance } from '../knife4j/Knife4jInstance';
import { TagObject, InfoObject, PathsObject, OperationObject, ExternalDocumentationObject, ServerObject } from "./types";
import { Knife4jPathItemObject } from '../knife4j/operation/Knife4jPathItemObject';
/**
 * 解析OpenAPI3的规范,参考规范文档：https://spec.openapis.org/oas/v3.1.0
 */
export declare class OpenAPIParser extends BaseCommonParser {
    /**
     * 解析OpenAPI3规范
     * @param data OpenAPI原始数据
     * @param options 解析Options
     * @returns
     */
    parse(data: Record<string, any>, options: Knife4jParseOptions): Knife4jInstance;
    /**
     * 异步解析Path节点，只有在打开文档展示页的情况下才解析该配置，避免前端解析渲染性能问题
     * @param instance 对象实例
     * @param options 个性化解析配置选项
    */
    parsePathAsync(operation: Knife4jPathItemObject, instance: Knife4jInstance, options: Knife4jParseOptions): void;
    /**
     * 解析tag
     * @param tagArray 分组源数据集
     * @param instance 实例对象
     */
    resolveTag(tagArray: TagObject[], instance: Knife4jInstance): void;
    /**
     * 解析info
     * @param info 基础信息
     * @param instance 实例
     */
    resolveInfo(info: InfoObject, instance: Knife4jInstance): void;
    /**
     * 解析paths对象
     * @param paths 路由paths
     * @param instance 对象实例
     */
    resolvePaths(paths: PathsObject, instance: Knife4jInstance): void;
    /**
     * path对象
     * @param operation path接口对象
     * @param url 接口url
     * @param methodType 接口类型，包括：POST\GET\PUT\DELETE
     * @param instance  对象实例
     */
    resolveOperation(operation: OperationObject, url: string, methodType: string, instance: Knife4jInstance): void;
    /**
     * 解析外部扩展文档信息
     * @param extdoc 外部扩展文档信息
     * @param instance 当前对象实例
     */
    resolveExternalDoc(extdoc: ExternalDocumentationObject, instance: Knife4jInstance): void;
    /**
     * 解析servers节点
     * @param servers servers数组信息
     * @param instance  对象实例
     */
    resolveServers(servers: ServerObject[], instance: Knife4jInstance): void;
}
