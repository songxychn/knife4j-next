import { Knife4jExternalDocumentationObject } from "../externalDoc/Knife4jExternalDocumentationObject";
import { Knife4jRequestBody } from '../schema/Knife4jRequestBody';
import { Knife4jSchema } from '../schema/Knife4jSchema';
import { ParameterObject, RequestBodyObject, ExternalDocumentationObject } from "../../openapi3/types";
import { Knife4jInstance } from '../Knife4jInstance';
/**
* Describes the operations available on a single path.
* A Path Item MAY be empty, due to ACL constraints.
* The path itself is still exposed to the documentation viewer but they will not know which operations and parameters are available.
*/
export declare class Knife4jPathItemObject {
    /**
     * url
     */
    url: string;
    /**
     * 接口类型
     */
    methodType: string;
    /**
     * Allows for an external definition of this path item.
     * Referencing a `$ref` requires the value of the property to be the URI of a valid OpenAPI Specification file.
     * This file MUST be hosted remotely and accessible via HTTP or HTTPS.
     * The value of the `$ref` field MUST be an RFC 3986 compliant URI.
     */
    $ref?: string;
    /**
     * An optional, string summary, intended to apply to all operations in this path.
     */
    summary?: string;
    /**
     * An optional, string description, intended to apply to all operations in this path.
     * CommonMark syntax MAY be used for rich text representation.
     */
    description?: string;
    /**
   * A list of tags for API documentation control.
   */
    tags?: string[];
    /**
     *  Additional external documentation for this operation.
     */
    extDoc?: Knife4jExternalDocumentationObject;
    /**
     * Unique string used to identify the operation.
     */
    operationId?: string;
    /**
     * 请求类型
     */
    consumer: string;
    /**
     * 响应类型
     */
    produces: string;
    /**
     * A list of parameters that are applicable for this operation.
     */
    parameters: Knife4jSchema[];
    /**
     * The request body applicable for this operation.
     * include 多种类型
     */
    requestBody: Knife4jRequestBody[];
    /**
     * Expected responses for this operation.
     */
    responses?: Record<string, unknown>;
    /**
     * A map of possible out-of band callbacks related to the parent operation.
     */
    callbacks?: Record<string, unknown>;
    /**
     * Declares this operation to be deprecated.
     */
    deprecated?: boolean;
    /**
     * A declaration of which security mechanisms can be used for this operation.
     */
    security?: [];
    /**
     * An alternative server array to service this operation.
     */
    servers?: [];
    constructor(url: string, methodType: string);
    /**
     * 新增参数
     * @param param 参数
     */
    addParameter(param: Knife4jSchema): void;
    /**
     * 解析OpenAPI3规范的外部文档参数
     * @param doc 外部文档
     */
    resolveOpenAPI3ExtDoc(doc: ExternalDocumentationObject | undefined): void;
    /**
     * 异步解析参数-OpenAPI3
     * @param parameters 参数集合
     * @param operation 当前operation对象
     */
    asyncResolveParameters(parameters: ParameterObject[] | undefined): void;
    /**
     * 异步解析请求参数
     * @param body 请求参数
     */
    asyncResolveRequestBody(body: RequestBodyObject | undefined, instance: Knife4jInstance): void;
}
