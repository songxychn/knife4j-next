import { SchemaObject } from "../../openapi3/types";
import { Knife4jSchema } from "./Knife4jSchema";
import { Knife4jInstance } from "../Knife4jInstance";
export declare class Knife4jRequestBody {
    /**
     * 请求类型，例如：application/json,application/xml等等
     */
    media: string;
    /**
   * A brief description of the request body. This could contain examples of use.
   */
    description?: string;
    /**
     * 示例值,根据不同的MediaType，依靠parameters生成example
     */
    example: string;
    /**
     * A list of parameters that are applicable for this operation.
     */
    parameters: Knife4jSchema[];
    /**
     * Determines if the request body is required in the request. Defaults to false.
     */
    required: boolean;
    constructor(media: string);
    /**
     * 解析requestBody
     * @param description 说明
     * @param required 是否必须
     * @param schema schema
     */
    resolveBody(description: string, required: boolean, schema: SchemaObject, instance: Knife4jInstance): void;
}
