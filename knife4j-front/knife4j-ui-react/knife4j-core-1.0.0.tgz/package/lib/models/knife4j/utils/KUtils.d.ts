declare const KUtils: {
    /**
     * 处理换行
     * @param str 换行字符
     */
    wrapLine(str: string): string;
    /**
     * 校验是否基础类型
     *  ("null","boolean", "object", "array", "number", or "string"), or "integer"
     * @param type 类型
     */
    basicType(type: string): boolean;
    /**
     * 获取基础类型的初始value值
     * @param type 类型
     * @returns
     */
    basicTypeValue(type: string): any;
};
export default KUtils;
