import { Knife4jExternalDocumentationObject } from "../externalDoc/Knife4jExternalDocumentationObject";
/**
 * tag内容
 */
export declare class Knife4jTagObject {
    /**
     * REQUIRED. The name of the tag.
     */
    name: string;
    /**
     * A short description for the tag. CommonMark syntax MAY be used for rich text representation.
     */
    description?: string;
    /**
     * tag顺序
     */
    order: number;
    /**
     * 当前tag下拥有的接口数量
     */
    count: number;
    /**
     * 支持多级别的Tag
     */
    children: Array<Knife4jTagObject>;
    /**
     * Additional external documentation for this tag.
     */
    externalDocs?: Knife4jExternalDocumentationObject;
    /**
     * 构造函数
     * @param name tag名称
     */
    constructor(name: string);
}
