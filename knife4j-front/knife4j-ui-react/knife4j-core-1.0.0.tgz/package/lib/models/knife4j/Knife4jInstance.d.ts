import { Knife4jTagObject } from "./tag/Knife4jTagObject";
import { Knife4jInfoObject } from "./info/Knife4jInfoObject";
import { Knife4jExternalDocumentationObject } from "./externalDoc/Knife4jExternalDocumentationObject";
import { Knife4jServer } from "./servers/Knife4jServer";
import { Knife4jParseOptions } from "./Knife4jParseOptions";
import { Knife4jPathItemObject } from "./operation/Knife4jPathItemObject";
import { ISpecParser } from "./ISpecParser";
import { Knife4jSchema } from "./schema/Knife4jSchema";
/**
 * 该类是所有parse方法最重输出的对象
 */
export declare class Knife4jInstance {
    originalRecord: Record<string, any>;
    /**当前规范数据的解析器，方便异步解析操作 */
    parseFactory: ISpecParser;
    parseOptions: Knife4jParseOptions;
    id: string;
    name: string;
    url: string;
    version: string;
    info: Knife4jInfoObject;
    tagNames: Record<string, number>;
    tags: Array<Knife4jTagObject>;
    paths: Array<Knife4jPathItemObject>;
    servers: Array<Knife4jServer>;
    extDoc?: Knife4jExternalDocumentationObject;
    schemaDict: {
        [schemaName: string]: Knife4jSchema;
    };
    /**
     * 构造函数
     * @param name 名称
     * @param location OpenAPI接口资源地址
     * @param version 版本，2.0或者3.0
     */
    constructor(name: string, location: string, version: string, factory: ISpecParser, options: Knife4jParseOptions);
    /**
     * 标签分组
     * @param tag 接口分组
     * @returns
     */
    addTag(tag: Knife4jTagObject): void;
    /**
     * tag分组下计数器+1
     * @param tagName tag名称
     */
    addTagCount(tagName: string): void;
    /**
     * 添加path
     * @param operation path对象
     */
    addOperation(operation: Knife4jPathItemObject): void;
    /**
     * 设置外部文档对象
     * @param ext 设置外部文档对象
     */
    setExtDoc(ext: Knife4jExternalDocumentationObject): void;
    /**
     * 设置servers信息
     * @param server server信息
     */
    addServer(server: Knife4jServer): void;
    /**
     * 根据接口路径path解析规则
     * @param path 接口路径path
     * @param methodType 接口类型，例如：post、get、delete等等
     */
    resolveSinglePathAsync(path: string, methodType: string): void;
}
