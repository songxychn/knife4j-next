import { SchemaObject } from '../../openapi3/types';
/**
 * string类型校验
 */
export declare class Knife4jValidateStringObject {
    /**
       * Maximum length of a string.
       */
    maxLength?: number;
    /**
     * Minimum length of a string.
     */
    minLength?: number;
    /**
     * Regular expression pattern for a string.
     */
    pattern?: string;
    /**
    * 解析schema-validate部分参数
    * @param schema schema对象
    */
    resolveOpenAPI3Schema(schema: SchemaObject): void;
}
