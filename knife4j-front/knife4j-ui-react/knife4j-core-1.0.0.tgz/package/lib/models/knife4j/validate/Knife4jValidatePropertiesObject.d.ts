import { SchemaObject } from '../../openapi3/types';
/**
 * 对象属性的校验
 */
export declare class Knife4jValidatePropertiesObject {
    /**
       * Maximum number of properties allowed in an object.
       */
    maxProperties?: number;
    /**
     * Minimum number of properties allowed in an object.
     */
    minProperties?: number;
    /**
     * List of required properties in an object.
     */
    required: string[];
    /**
   * 解析schema-validate部分参数
   * @param schema schema对象
   */
    resolveOpenAPI3Schema(schema: SchemaObject): void;
    /**
     * 判断当前参数是否必须
     * @param name 属性名称
     */
    isReuqire(name: string): boolean;
}
