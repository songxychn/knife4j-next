import { SpecType } from './SpecType';
import { ISpecParser } from './knife4j/ISpecParser';
/**
 * 工厂类
 */
export declare class SpecParserFactory {
    /**
     * 工厂Map
     */
    private parsers;
    constructor();
    /**
     * 注册实例
     * @param specType 规范类型
     * @param parser 转换器
     */
    registerParser(specType: SpecType, parser: ISpecParser): void;
    /**
     * 获取parse实例对象
     * @param parserType 规范类型
     * @returns
     */
    getParser(parserType: SpecType): ISpecParser;
}
