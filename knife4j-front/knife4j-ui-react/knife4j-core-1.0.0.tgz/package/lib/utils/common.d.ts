/**
 * 常用工具类
 */
declare const CommonUtils: {
    say(): void;
    getNumber(): number;
};
export default CommonUtils;
