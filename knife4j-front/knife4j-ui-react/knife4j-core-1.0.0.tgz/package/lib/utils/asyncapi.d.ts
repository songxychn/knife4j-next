/**
 * AsyncAPI 规范的工具函数
 */
declare const AsyncAPIUtils: {
    say(): void;
};
export default AsyncAPIUtils;
