/**
 * Swagger2 规范的工具函数
 */
declare const Swagger2Utils: {
    say(): void;
};
export default Swagger2Utils;
