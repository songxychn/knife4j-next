/**
 * OpenAPI3 规范的工具函数
 */
declare const OpenAPI3Utils: {
    say(): void;
};
export default OpenAPI3Utils;
